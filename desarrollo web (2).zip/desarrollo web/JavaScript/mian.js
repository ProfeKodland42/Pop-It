const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("nav-menu");
const closeBtn = document.querySelector(".cross");

// Abrir menú: mostrar nav y ocultar el botón hamburguesa
hamburger.addEventListener("click", () => {
  navMenu.classList.add("active");
  hamburger.style.display = "none"; // ocultamos el botón para que no se vea detrás
});

// Cerrar menú: ocultar nav y volver a mostrar el botón
closeBtn.addEventListener("click", () => {
  navMenu.classList.remove("active");
  hamburger.style.display = ""; // restaura el valor por defecto
});
